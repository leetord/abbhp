## 在电脑客户端 v2RayN 中使用此项目所部署的VLESS

本项目部署后，可以在电脑上用客户端v2RayN来使用所部署的VLESS节点

可以用80端口或443端口，配置稍有不同。图例如下：

****

在电脑客户端 v2RayN 中配置：

***

使用443端口：

![443端口图示](/tutorial/img/Windows-v2RayN-VLESS-443.png)

***

用Cloudflare反代后，使用443端口：

![80端口图示](/tutorial/img/Windows-v2RayN-VLESS-443+Cloudflare.png)

***
